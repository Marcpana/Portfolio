<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Works extends CI_Controller {

	public function index()
	{
		$this->load->view('core/headers');
        $this->load->view('core/works');
        $this->load->view('core/footer');
	}
}
