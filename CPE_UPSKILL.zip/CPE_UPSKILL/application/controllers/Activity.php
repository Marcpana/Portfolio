<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Activity extends CI_Controller {

	public function index()
	{
		$this->load->view('core/headers');
        $this->load->view('core/activity');
        $this->load->view('core/footer');
	}
}