<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Works</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
  </body>
  <center>
  <br>
  <div class="h4 pb-2 mb-4 text-primary border-bottom border-primary"> <h1>WORKS</h1></div>
            <span class="badge text-bg-primary"><h2>Infographic</h2></span><br><br>
            <div class="p-3 mb-2 bg-Warning text-dark">
<div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/work1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">ออกแบบโปสเตอร์</h5>
        <p class="card-text">ออกแบบโปสเตอร์ประชาสัมพันธ์งานพิธีไหว้ครูของคณะวิทยาศาสตร์และเทคโนโลยีการเกษตร มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา ตาก</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">  
      <img src="<?php echo base_url('img');?>/work2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">ออกแบบโปสเตอร์</h5>
        <p class="card-text">ออกแบบโปสเตอร์ประชาสัมพันธ์โครงการแห่เทียนจำนำพรรษาของคณะวิทยาศาสตร์และเทคโนโลยีการเกษตร มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา ตาก</p>
      </div>
    </div>
    </div>
  </div>
</div>



<div class="p-3 mb-2 bg-info text-dark">
<span class="badge text-bg-light"><h2>Digital Art</h2></span><br><br>
<div class="row row-cols-2 row-cols-md-6 g-4">
  <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/cat1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Cute Cat 01</h5>
        <p class="card-text">เปลี่ยนแมวเหมียวให้เป็นการ์ตูนสุดน่ารัก</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/cat2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Cute Cat 02</h5>
        <p class="card-text">เปลี่ยนแมวเหมียวให้เป็นการ์ตูนสุดน่ารัก</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/cat3.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Cute Cat 03</h5>
        <p class="card-text">เปลี่ยนแมวเหมียวให้เป็นการ์ตูนสุดน่ารัก</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/cat4.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Cute Cat 04</h5>
        <p class="card-text">เปลี่ยนแมวเหมียวให้เป็นการ์ตูนสุดน่ารัก</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/cat5.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Cute Cat 05</h5>
        <p class="card-text">เปลี่ยนแมวเหมียวให้เป็นการ์ตูนสุดน่ารัก</p>
      </div>
    </div>
  </div>
   <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/cat6.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Cute Cat 06</h5>
        <p class="card-text">เปลี่ยนแมวเหมียวให้เป็นการ์ตูนสุดน่ารัก</p>
      </div>
    </div>
  </div>
</div>
</center>
<div class="p-3 mb-2 bg-dark text-dark">
<center>
<span class="badge text-bg-success"><h2>My Sticker LINE</h2></span><br><br>
</center> 


<div class="row">
  <div class="col-sm-6">
  <div class="card text-bg-success mb-3">
      <div class="card-body">
      <img src="<?php echo base_url('img');?>/line.png" class="card-img-top" alt="...">
      <center>
      <br><br><h5 class="card-title">ออกแบบสติกเกอร์ไลน์</h5>
        <p class="card-text"></p>
        <a href="https://store.line.me/stickershop/product/16845107/en?from=sticker" class="btn btn-dark">Purchase</a>
        </center> 
    </div>
  </div>
  </div>
  <div class="col-sm-6">
  <div class="card text-bg-success mb-3">
      <div class="card-body">
      <img src="<?php echo base_url('img');?>/line2.png" class="card-img-top" alt="...">
      <center>
      <br><br><h5 class="card-title">ออกแบบสติกเกอร์ไลน์</h5>
        <p class="card-text"></p>
        <a href="https://store.line.me/stickershop/product/14191123/en?from=sticker" class="btn btn-dark">Purchase</a>
        </center> 
    </div>