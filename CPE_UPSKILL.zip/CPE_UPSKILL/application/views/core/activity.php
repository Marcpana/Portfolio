<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Works</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
  </body>
  <center>
  <div class="p-3 mb-2 bg-info text-dark">
  <br>
<div class="h4 pb-2 mb-4 text-dark border-bottom border-dark"> <h1>ACTIVITY</h1>

<div class="p-3 mb-2 bg-info text-dark">
<div class="row row-cols-1 row-cols-md-3 g-4">
  <div class="col">
    <div class="card">
      <img src="<?php echo base_url('img');?>/good.jpg" class="card-img-top" alt="...">
      <div class="card-body">
      <br><br><br><h5 class="card-title">แข่งขัน Idea Pitching</h5>
        <p class="card-text">ณ มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา น่าน</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">  
      <img src="<?php echo base_url('img');?>/rov1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">แข่งขัน ROV</h5>
        <p class="card-text">กิจกรรมภายในคณะวิทยาศาสตร์ มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา ตาก</p>
      </div>
    </div>
    </div>
  
  <div class="col">
    <div class="card">  
      <img src="<?php echo base_url('img');?>/rov2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
      <br><br><br><h5 class="card-title">แข่งขัน ROV</h5>
        <p class="card-text">กิจกรรมภายในมหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา ตาก</p>
      </div>
      
    
