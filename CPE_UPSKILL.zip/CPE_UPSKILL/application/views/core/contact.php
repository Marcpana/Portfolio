<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Works</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
  </body>
  <div class="p-3 mb-2 bg-dark text-white">
<center>
<br>
  <div class="h4 pb-2 mb-4 text-primary border-bottom border-primary"> <h1>CONTACT ME</h1></div>
  <img src="<?php echo base_url('img');?>/me3.jpg" class="img-circle" alt="Cinque Terre" width="300" height="300"alt="">
  <br><br>
  <div class="row row-cols-1 row-cols-md-3 g-2">
  <div class="col">
    <div class="card h-10 ">
    <br><br><center>
      <img src="<?php echo base_url('img');?>/face.png" class="img-circle" alt="Cinque Terre" width="100" height="100"alt=""  alt="...">
</center>
      <div class="card-body">
      <a class="btn btn-dark" href="https://www.facebook.com/panarak.kakan/photos" role="button">FACEBOOK</a><br><br>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
    <br><br><center>
      <img src="<?php echo base_url('img');?>/linee.png" class="img-circle" alt="Cinque Terre" width="100" height="100"alt=""  alt="...">
</center>
      <div class="card-body">
      <a class="btn btn-dark" href="https://line.me/ti/p/SdVCL9dyDa" role="button">LINE</a><br><br>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
    <br><br><center>
      <img src="<?php echo base_url('img');?>/ig.png" class="img-circle" alt="Cinque Terre" width="100" height="100"alt=""  alt="...">
</center>
      <div class="card-body">
      <a class="btn btn-dark" href="https://www.instagram.com/marc.txs/" role="button">INSTARGRAM</a><br><br>
      </div>
    </div>
  </div>
</div> 


<br>
  <img src="<?php echo base_url('img');?>/phone.png" class="img-circle" alt="Cinque Terre" width="25" height="25"alt="0987939662">
  <p class="fw-bolder">0987939662</p>
</center>
  </div>