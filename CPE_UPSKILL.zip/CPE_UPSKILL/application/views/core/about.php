<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About Me</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
  </body>
<body>
<center>
    
<main id="main" class="site-main">

<br>
            <div class="col-md-6 col-md-offset-3">
            <div class="h4 pb-2 mb-4 text-primary border-bottom border-primary"> <h1>ABOUT ME</h1></div>
            <div id="carouselExampleControlsNoTouching" class="carousel slide" data-bs-touch="false">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo base_url('img');?>/mepana.jpg" class="d-block w-50" alt="...">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url('img');?>/me1.jpg" class="d-block w-50" alt="...">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url('img');?>/me2.jpg" class="d-block w-50" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
                <figure class="text-center">
                <blockquote class="blockquote">
                    <p>When we strive to become better than we are, everything around us becomes better too.</p>
                </blockquote>
                    <figcaption class="blockquote-footer">
                        Marc <cite title="Source Title">Panarak</cite>
                    </figcaption>
                    <div class="p-3 bg-info bg-opacity-10 border border-info border-start-0 rounded-end"><h4>Personal Information</h4></div>
            </figure>
            
            <table class="table">
  <thead>
  <tbody>
    <tr>
      <th scope="row">Name</th>
      <td>Panarak Kakan</td>
    </tr>
    <tr>
      <th scope="row">Date of Birth</th>
      <td>12/12/2001</td>
    </tr>
    <tr>
      <th scope="row">Age</th>
      <td>20</td>
    </tr>
    <tr>
      <th scope="row">Education</th>
      <td>Bachelor drgree</td>
    </tr>
    <tr>
      <th scope="row">Marital Status</th>
      <td>Single</td>
    </tr>
  </tbody>
</table>
</figcaption>
                    <div class="p-3 bg-info bg-opacity-10 border border-info border-start-0 rounded-end"><h5></h5></div>
            </figure>
</center>
